#include <set>
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <cstdlib>
#include <map>
#include <vector>

using namespace std;

string LimpiarPalabra(string palabra);
set<string> GuardarPalabras(set<string> Bpalabras, string linea);
set<string> BDPalabras();
class Preguntas
{
	private:
			vector<string>tyc;//titulo y cuerpo de la pregunta
			string clase;//clase a la que pertenece
			map<int,int> contpal;//contador de las palabras que hay
	public:
		void InsertarPalabras(string palabra);
		void setClase(string);
		void InsertarContPal(int,int);
		vector<string>getTyC();
		string getClase();
		map<int,int> getContPal();
		void Imprimir();
};

void Preguntas::InsertarPalabras(string palabra)
{
	palabra = LimpiarPalabra(palabra);
	tyc.push_back(palabra);
}
void Preguntas::Imprimir()
{
	cout<<clase<<" ";
	vector<string>::iterator it;
	for(it=tyc.begin(); it!=tyc.end(); it++)
	{
		cout<<*it<<" ";
	}
	cout<<endl;
}
void Preguntas::setClase(string cl){	clase = cl;	}
void Preguntas::InsertarContPal(int key, int valor){ contpal[key]=valor;	}
vector<string> Preguntas::getTyC(){	return tyc;	}
string Preguntas::getClase(){	return clase;	}
map<int,int> Preguntas::getContPal(){ return contpal;}

Preguntas GuardarPregunta(string palabra)
{
	Preguntas auxp;
	istringstream is(palabra);
	string part;
	while(getline(is,part,' '))
	{
		auxp.InsertarPalabras(part);
	}
	return auxp;
}

vector<Preguntas> ContarPalabras(vector<Preguntas> BDpre, map<string,int>BDpal)
{
	vector<Preguntas> auxBD;
	vector<Preguntas>::iterator itpre;
	int i=0;
	for(itpre = BDpre.begin(); itpre!=BDpre.end(); itpre++)
	{
		Preguntas pre = *itpre;
		vector<string>tyc = pre.getTyC();
		vector<string>::iterator ittyc;
		for(ittyc= tyc.begin(); ittyc != tyc.end(); ittyc++)
		{
			int cont=0;
			vector<string>::iterator auxit;
			for(auxit= tyc.begin(); auxit!= tyc.end(); auxit++)
			{
				if(*ittyc== *auxit)
				{//if(*ittyc=="a") cout<<"FUN CONTPAL----"<<*ittyc<<endl;
					cont=cont+1;
				}
			}
			if(cont!=0)
				pre.InsertarContPal(BDpal[*ittyc],cont);
			
		}
		auxBD.push_back(pre);

	}
	return auxBD;
}
int main()
{	
	set<string>Bpalabras = BDPalabras();//se guardaran todas las palabras
	cout<<"Total de palabras: "<<Bpalabras.size()<<endl;
	set<string>::iterator itbp;
	
	map<string,int>BDpal;
	map<int,string>BDpal1;
	int i=1;
	ofstream salidapalabras("Palabras.dat");
	for(itbp= Bpalabras.begin(); itbp!= Bpalabras.end(); itbp++)
	{
		string auxp=*itbp;
		BDpal[auxp] = i;
		BDpal1[i]=auxp;
		salidapalabras<<i<<" "<<auxp<<endl;
		i++;
	}
	salidapalabras.close();
/************************************************************************
************nombre del archivo de entrada********************************
************************************************************************/
	ifstream archivo("datos.txt");
	
	string linea;
	string palabra;
	set<string>clases;
	vector<Preguntas>BDpreguntas;//vector donde se guardaran todas las preguntas
	while(getline(archivo, linea))
	{
		Preguntas pregunta;
		//cout<<linea<<endl;
		istringstream is(linea);
		string part;
		//separo la linea por tab quedando tituloCuerpo separado de la etiqueta
		int x=0;

		while(getline(is, part,'	'))
		{
			//cout<<part<<endl;
			if(x==0)
			{
				pregunta = GuardarPregunta(part);
				x=1;
			}
			else
			{
				pregunta.setClase(part);
				clases.insert(part);
				x =0;
			}
		}
		BDpreguntas.push_back(pregunta);
	}
	archivo.close();
	cout<<"Total de Pregutnas: "<<BDpreguntas.size()<<endl;
	cout<<"Total de Clases: "<<clases.size()<<endl;
	
	map<string,int>tclases;//asignandole un valor a cada clase
	set<string>::iterator itc;
	int cont=1;
	for(itc=clases.begin(); itc!=clases.end(); itc++)
	{
		tclases[*itc]=cont;
		cont++;
	}
	
	BDpreguntas = ContarPalabras(BDpreguntas,BDpal);
	
	vector<Preguntas>::iterator it1;
	map<int,int>::iterator itm;
/****************************************************************************/
//nombre archivo de salida
	ofstream salida("modelo.dat");
	ofstream salida1("model.dat");
	for(it1=BDpreguntas.begin(); it1!=BDpreguntas.end(); it1++)
	{
		Preguntas pregunta = *it1;
		map<int,int> aux1 = pregunta.getContPal();
		//cout<<tclases[pregunta.getClase()]<<" ";
		salida<<tclases[pregunta.getClase()]<<" ";
		salida1<<pregunta.getClase()<<" ";
		for(itm=aux1.begin();itm!=aux1.end();itm++)
		{
			//cout<<itm->first<<":"<<itm->second<<" ";
			if(itm->first!=0)
			{
				salida<<itm->first<<":"<<itm->second<<" ";
				salida1<<BDpal1[itm->first]<<":"<<itm->second<<" ";
			}
		}
		//cout<<endl;
		salida<<endl;
		salida1<<endl;
		//pregunta.Imprimir();
	}
	
	salida.close();
	salida1.close();
}


set<string> BDPalabras()
{
/************************************************************************
************nombre del archivo de entrada********************************
************************************************************************/
	ifstream archivo("datos.txt");
	
	string linea;
	string palabra;
	set<string>Bpalabras;//se guardaran todas las palabras
	while(getline(archivo, linea))
	{
		//cout<<linea<<endl;
		istringstream is(linea);
		string part;
		//separo la linea por tab quedando tituloCuerpo separado de la etiqueta
		int x=0;
		while(getline(is, part,'	'))
		{
			//cout<<part<<endl;
			if(x==0)
			{
				Bpalabras = GuardarPalabras(Bpalabras,part);
				x=1;
			}
			else x =0;
		}
	}
	archivo.close();
	return Bpalabras;
}


set<string> GuardarPalabras(set<string> Bpalabras, string linea)
{
	istringstream is(linea);
	string part;
	while (getline(is,part,' '))
	{
		//cout<<part<<endl;
		part = LimpiarPalabra(part);
		//cout<<part<<endl;
		if(part!="")
			Bpalabras.insert(part);
	}
	return Bpalabras;
}

string LimpiarPalabra(string palabra)
{
	string auxpal="";
	for(int i=0; i<palabra.size(); i++)
	{
		
		if(palabra[i]>=65 && palabra[i]<=90)
		{
			char auxc = palabra[i]+32;
			auxpal=auxpal+auxc;
		}
		else if (palabra[i]>=97 && palabra[i]<=122)
			auxpal = auxpal+palabra[i];
	}
	return auxpal;
}
