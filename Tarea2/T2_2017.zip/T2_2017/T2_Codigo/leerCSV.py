#enconding utf-8
import csv
from nltk.corpus import stopwords
from nltk.tokenize import sent_tokenize, word_tokenize

stop_words = set(stopwords.words("english"))

reader = csv.reader(open('datos.csv','rb'),delimiter = ',')

"""	se va recorriendo cada fila del archivo dato.csv
	se debe de eliminar la primera fila la que contiene Titulo Cuerpo Etiqueta
	Para acceder a cada columna del archivo es a traves de row[indice]"""

f = open("datos.txt","w");
x=0
cont = 1

for index,row in enumerate(reader):
	#print'Datos '+str(index+1)
	#print'-----------------'
	#print'Titulo: '+row[0]
	#print'cuerpo: '+row[1]
	#print'Etiq: '+row[2]
	#print'\n'
	#el .split() separa la cadena por palabras y quita todo tipo de espacio
	a = row[0].split()
	#b = row[1].split()
	w=""
	z=""
	for i in a:
		z=z+" "+i
	z=z+" "
	
	z=z.lower()
	#if cont ==1 : print(z)
	
	
	for i in word_tokenize(z.decode("utf-8")):
		if i not in stop_words: f.write(i.encode("utf-8")+" ")		
		#if i not in stop_words: w=w+" "+i
		

	#cont = cont + 1
	#print (w)

	#Solo si no es una stop_words , la escribo
	#f.write(w)
	f.write("\t")
	f.write(row[1])
	f.write("\n")
	w=""	

f.close()

	
